import lmql.runtime.lmql_runtime as lmql

@lmql.query(None)
async def query(context=None):
   context.set_model('openai/text-davinci-003')
   context.set_decoder('argmax', )
   # where
   context.set_where_clause(None)
   # prompt
   (yield context.query(f'A list of good dad jokes. A indicates the punchline \n'))
   (yield context.query(f'Q: How does a penguin build its house? \n'))
   (yield context.query(f'A: Igloos it together. END \n'))
   (yield context.query(f"Q: Which knight invented King Arthur's Round Table? \n"))
   (yield context.query(f'A: Sir Cumference. END \n'))
   (yield context.query(f'Q:[JOKE] \n'))
   JOKE = context.get_var('JOKE')
   (yield context.query(f'A:[PUNCHLINE] \n'))
   PUNCHLINE = context.get_var('PUNCHLINE')
   yield ('result', context.get_return_value())
