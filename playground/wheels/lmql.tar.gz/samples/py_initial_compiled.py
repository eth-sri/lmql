import lmql_runtime as lmql
import query_utils

def query(QUESTION=None):
   lmql.set_model('gpt-2')
   # where
   intm0 = lmql.OpaqueLambdaOp(lambda EXPERT_NAME: lmql.words(EXPERT_NAME), lmql.Var('EXPERT_NAME'))
   intm1 = lmql.Lt([intm0, 2])
   intm2 = set(['A', 'B', 'C. D'])
   intm3 = lmql.OneOf([lmql.Var('EXPERT_NAME'), intm2])
   intm4 = lmql.OpaqueLambdaOp(lambda ANSWER: all([(W not in blacklist) for W in ANSWER]), lmql.Var('ANSWER'))
   intm5 = lmql.OpaqueLambdaOp(lambda EXPERT_NAME: all([(W not in blacklist) for W in EXPERT_NAME]), lmql.Var('EXPERT_NAME'))
   intm6 = lmql.OpaqueLambdaOp(lambda ANSWER: all([(E in known_entities) for E in lmql.entities(S) for S in lmql.sentences(ANSWER, 4)]), lmql.Var('ANSWER'))
   intm7 = lmql.OpaqueLambdaOp(lambda ANSWER: query_utils.parser(ANSWER), lmql.Var('ANSWER'))
   intm8 = lmql.EqOp([intm7, True])
   intm9 = lmql.AndOp([
     intm1,
     intm3,
     intm4,
     intm5,
     intm6,
     intm8
   ])
   # prompt
   lmql.query(f'A: {QUESTION}')
   lmql.query(f'B: I believe the best person to answer this question is [EXPERT_NAME]')
   EXPERT_NAME = lmql.get_var('EXPERT_NAME')
   lmql.query(f'Indeed, in a recent interview {EXPERT_NAME} addressed this question:')
   for i in range(2):
       lmql.query(f'[ANSWER]')
       ANSWER = lmql.get_var('ANSWER')
       lmql.query(f'{query_utils.scripted_prompt(ANSWER, EXPERT_NAME)}')
       lmql.query(f'[ANSWER2]')
       ANSWER2 = lmql.get_var('ANSWER2')
   return locals()
