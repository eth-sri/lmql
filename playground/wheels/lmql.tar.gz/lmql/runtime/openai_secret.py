import os

openai_secret = None
openai_org = None

# get project root
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

if not os.path.exists(os.path.join(ROOT_DIR, "api.env")) and not "LMQL_BROWSER" in os.environ:
    raise FileNotFoundError("""api.env not found in project root. Please create a file of the following format:
openai-secret: <your openai secret>
openai-org: <your openai org>
""")

if "LMQL_BROWSER" in os.environ:
    # get openai secret from JS context
    import js
    openai_secret = str(js.get_openai_secret())
    openai_org = str(js.get_openai_organization())
else:
    # get openai secret from file
    with open(os.path.join(ROOT_DIR, "api.env"), "r") as f:
        for line in f:
            if line.startswith("openai-secret: "):
                openai_secret = line.split("openai-secret: ")[1].strip()
            elif line.startswith("openai-org: "):
                openai_org = line.split("openai-org: ")[1].strip()