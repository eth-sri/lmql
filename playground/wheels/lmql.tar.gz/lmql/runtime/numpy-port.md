# NumPy Port

* logical_or, logical_and