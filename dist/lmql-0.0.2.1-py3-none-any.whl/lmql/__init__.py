def run():
    print("This it he LMQL placeholder package.")
