from lmql.ops.ops import execute_op, is_node
from lmql.ops.follow_map import *
