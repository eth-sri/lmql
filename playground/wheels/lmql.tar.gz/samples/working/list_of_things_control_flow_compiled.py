import lmql.runtime.lmql_runtime as lmql

@lmql.lmql_query
async def query(context=None):
   lmql.set_model('gpt2-medium')
   lmql.set_decoder('SAMPLE', n=2)
   # where
   intm0 = lmql.OneOf([lmql.Var('THING'), set(['Beach Volleyball', 'Sunscreen', 'Bathing Suite'])])
   intm1 = lmql.AndOp([
     intm0,
     lmql.OpaqueLambdaOp([lambda THING: all([(len(THING) < 12) for t in range(12)]), [lmql.Var('THING')]])
   ])
   lmql.set_where_clause(intm1)
   # prompt
   (yield context.query(f'A list of things not to forget when going to the sea (not travelling): \n'))
   (yield context.query(f'- Sunglasses \n'))
   for i in range(4):
       (yield context.query(f'- [THING] \n'))
       THING = context.get_var('THING')
   yield ('result', context.prompt)
