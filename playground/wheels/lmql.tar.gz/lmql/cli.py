import sys
import subprocess
import os
import argparse

project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def cmd_usage():
    """
    emoji:❓ show usage information
    """
    commands = [f for f in globals().values() if callable(f) and f.__name__.startswith("cmd_")]
    commands = [(f.__name__[4:], f.__doc__ or "<no description") for f in commands]

    def format_command_line(c, doc):
        emoji = "   "
        doc = doc.strip()
        if doc.startswith("emoji:"):
            emoji, doc = doc[len("emoji:"):].split(" ", 1)
            emoji += " "
            doc = doc.strip()
        return emoji + c.replace("_", "-") + " " * (20 - len(c)) + " " + doc

    command_list = "\n".join(["  " + format_command_line(name, doc) for name, doc in commands])
    print(f"""USAGE: lmql <command>

Commands:
{command_list}
""")

def cmd_serve_model():
    """emoji:🏄‍♂️ Serve a 🤗 Transformers model via the LMQL inference API"""
    os.chdir(project_root)
    os.system("python -m lmql.model.serve " + " ".join(sys.argv[2:]))

def cmd_run():
    """
    emoji:🏃‍♂️ run a LMQL script (e.g. "lmql run samples/argmax_a_joke.lmql")
    """
    import asyncio

    parser = argparse.ArgumentParser(description="Runs a LMQL program.")
    parser.add_argument("lmql_file", type=str, help="path to the LMQL file to run")
    parser.add_argument("--no-clear", action="store_true", dest="no_clear", help="don't clear inbetween printing results")
    parser.add_argument("--no-realtime", action="store_true", dest="no_realtime", help="don't print text as it's being generated")

    args = parser.parse_args(sys.argv[2:])

    absolute_path = os.path.abspath(args.lmql_file)
    os.chdir(os.path.join(project_root, "lmql/ui"))
    
    sys.path.append(os.path.join(project_root, "lmql/ui"))
    from lmql.ui.live import lmql_main
    from lmql.runtime.output_writer import PrintingDebuggerOutputWriter

    writer = PrintingDebuggerOutputWriter()
    writer.clear = not args.no_clear
    writer.print_output = not args.no_realtime

    asyncio.run(lmql_main(absolute_path, output_writer=writer))

def cmd_dev():
    """
    emoji:🧑‍💻 runs LMQL in development mode (hot-reloading python and debugger implementation)
    """
    parser = argparse.ArgumentParser(description="Runs LMQL in development mode (hot reloading, debugger, etc.)")
    parser.add_argument("--live-port", type=int, default=3004, help="port to use to host the LMQL live server")
    parser.add_argument("--ui-port", type=int, default=3000, help="port to use to host the LMQL debugger UI")
    
    args = parser.parse_args(sys.argv[2:])

    print(args)

    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    print(f"[lmql dev {project_root}, liveserver=localhost:{args.live_port}, ui=localhost:{args.ui_port}]")

    # make sure yarn is installed
    os.system("npm install -g yarn")

    # repo commit
    commit = subprocess.check_output("git rev-parse HEAD", shell=True, cwd=project_root).decode("utf-8").strip()
    commit = commit[:7]
    has_uncomitted_files = len(subprocess.check_output("git status --porcelain", shell=True, cwd=project_root).decode("utf-8").strip()) > 0
    if has_uncomitted_files:
        commit += " (dirty)"

    # live server that executes LMQL queries and returns results and debugger data
    live_process = subprocess.Popen("yarn && PORT=" + str(args.live_port) + " node index.js", 
        shell=True, cwd=os.path.join(project_root, "lmql/ui"))

    # UI that displays the debugger (uses live server API for data and remote execution)
    ui_modern_process = subprocess.Popen(f"yarn && REACT_APP_BUILD_COMMIT='{commit}' REACT_APP_SOCKET_PORT={args.live_port} yarn run start", 
        shell=True, cwd=os.path.join(project_root, "lmql/ui/modern"))

    try:
        live_process.wait()
        ui_modern_process.wait()
    except KeyboardInterrupt:
        print("[lmql dev] Ctrl+C pressed, exiting...")
        live_process.terminate()
        ui_modern_process.terminate()

def main():
    if len(sys.argv) < 2:
        cmd_usage()
        sys.exit(1)
    # get all functions defined in this file
    functions = [f for f in globals().values() if callable(f)]
    # get all functions that start with "cmd_"
    commands = [f for f in functions if f.__name__.startswith("cmd_")]
    # get the command function
    command = [f for f in commands if f.__name__ == "cmd_" + sys.argv[1] or f.__name__ == "cmd_" + sys.argv[1].replace("-", "_")]
    if len(command) == 0:
        print("Unknown command: " + sys.argv[1])
        cmd_usage()
        sys.exit(1)
    command[0]()

if __name__ == "__main__":
    main()