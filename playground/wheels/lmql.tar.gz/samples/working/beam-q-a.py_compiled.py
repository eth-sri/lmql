import lmql.runtime.lmql_runtime as lmql

@lmql.lmql_query
async def query(context=None):
   lmql.set_model('gpt2-medium')
   lmql.set_decoder('BEAM', do_sample=True, num_beams=4, no_repeat_ngram_size=3, length_penalty=0.7, temperature=0.4)
   # where
   intm0 = lmql.OneOf([lmql.Var('EXPERT_NAME'), ['Stephen Hawking', 'Bill Nye', 'a geographer']])
   intm1 = lmql.Gt([lmql.LenOp([lmql.Var('ANSWER')]), 0])
   intm2 = lmql.Lt([lmql.LenOp([lmql.WordsOp([lmql.Var('ANSWER')])]), 10])
   intm3 = lmql.Gt([lmql.LenOp([lmql.WordsOp([lmql.Var('ANSWER')])]), 3])
   intm4 = lmql.AndOp([
     intm0,
     intm1,
     intm2,
     intm3,
     lmql.StopAtOp([lmql.Var('ANSWER'), '\n'])
   ])
   lmql.set_where_clause(intm4)
   # prompt
   (yield context.query(f'A: What is the circumference of the earth? \n'))
   (yield context.query(f'B: I believe the best person to answer this question is [EXPERT_NAME]. \n'))
   EXPERT_NAME = context.get_var('EXPERT_NAME')
   (yield context.query(f'C: Indeed, {EXPERT_NAME} said:'))
   (yield context.query(f'The earth circumference is [ANSWER]'))
   ANSWER = context.get_var('ANSWER')
   yield ('result', context.prompt)
