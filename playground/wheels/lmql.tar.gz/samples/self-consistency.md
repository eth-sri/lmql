# self-consistency: https://arxiv.org/pdf/2203.11171.pdf

```sql
SAMPLE(n=3) -- can be top-k, nucleus, etc.
    "Q: If there are 3 cars in the parking lot and 2 more cars arrive, how many cars are in the parking lot?"
    "[REASONING] "
    "The answer is [ANSWER]"
FROM
    "gpt-3"
WHERE
    is_int(words(ANSWER, 0)) and len(words(ANSWER)) == 1
```

- `SAMPLE(n=3)` indicates that 3 sequences should be sampled.
    - alternatively one may use `TOPK(n=3)` or `BEAM(n=3)`
- `INT(answer)` makes sure that ANSWER can be parsed as integer (additional validation).
- `GROUP BY ANSWER` groups the resulting sequences by `ANSWER` accumulating counts per answer.


# PyLQ

```python
@lmql.sample(n=3)
def self_consistency():
    q"Q: If there are 3 cars in the parking lot and 2 more cars arrive, how many cars are in the parking lot?"
    q"[REASONING]"
    
    q"The answer is [ANSWER]" where int(answer)

    groupby int(answer)
```

