#! python
import argparse
import os

parser = argparse.ArgumentParser()
parser.add_argument("model", type=str, help="The HuggingFace identifier of the model to use.")
parser.add_argument("git_access_token", type=str, help="The access token to use to clone the LMQL repo")
# port
parser.add_argument("port", type=int, help="The port to serve the model on.", default=8089)
# detach or short -d
parser.add_argument("--interactive", "-i", default=False, help="Run the container in interactive mode, i.e. attach to its i/o.", action="store_true")

args = parser.parse_args()

detach_arg = "-d" if not args.interactive else "-it"
ip_mapping = f"-p {args.port}:8080"

print(f"Inference container will serve API at :{args.port}")
os.system(f"docker run --mount source=transformers-cache,target=/transformers --gpus all {detach_arg} {ip_mapping} lmql-serve {args.git_access_token} {args.model}")

