import lmql.runtime.lmql_runtime as lmql

async def query():
   lmql.set_model('mock')
   lmql.set_decoder('ARGMAX', no_repeat_ngram_size=2)
   # where
   lmql.set_where_clause(None)
   # prompt
   for i in range(2):
       (await lmql.query(f'Hello [SUBJECT]'))
       SUBJECT = lmql.get_var('SUBJECT')
   return lmql.get_default_result()
