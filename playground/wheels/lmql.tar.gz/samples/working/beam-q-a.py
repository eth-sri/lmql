BEAM(do_sample=True, num_beams=4, no_repeat_ngram_size=3, length_penalty=0.7, temperature=0.4)
   "A: What is the circumference of the earth? \n"
   "B: I believe the best person to answer this question is [EXPERT_NAME]. \n"
   "C: Indeed, {EXPERT_NAME} said:"
   "The earth circumference is [ANSWER]"
FROM
   'gpt2-medium'
WHERE
    EXPERT_NAME in ["Stephen Hawking", "Bill Nye", "a geographer"] and len(ANSWER) > 0 and 
    len(WORDS(ANSWER)) < 10 and len(WORDS(ANSWER)) > 3 and STOPS_AT(ANSWER, "\n")
