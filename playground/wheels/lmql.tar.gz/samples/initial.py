beam(p=4, k=2)
    .prompt(
        "A: {QUESTION}"
        "B: I belive the best person to answer this question is [EXPERT_NAME]"
    "Indeed, in a recent interview [EXPERT_NAME] addressed this question:"
    "[ANSWER]"
    "{scripted_prompt(ANSWER, EXPERT_NAME)}"
    "[ANSWER2]"
    ) \
    .from("gpt-j-6b") \
    .where(lambda: len(words(expert_name)) <= 2)
