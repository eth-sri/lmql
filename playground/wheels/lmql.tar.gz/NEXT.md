# Next Steps

## Decoding

* think about backtracking
    - SMT for better constraint solving
    
* think about beam search optimality and scripted prompting
    - is eos the correct stopping criterion?
    - non-end-to-end beam search
    - hole-to-hole beam search ?

## Outer Loop

* embedded queries (e.g. think-sum)

* aggregation
    - simple counting for e.g. group-by
    - marginalization for e.g. think-sum

* use (batched) models in validation (e.g. entity tagging)

## Models

* investigate integration GPT-3 API 
    * support for logit bias and token filtering exists https://beta.openai.com/docs/api-reference/completions/create
    * problem: Every generated token bills as len(prompt)+1. In regular decoding, you only get billed len(prompt)+len(response).
        - optimization: chunk-wise generation if no constraints currently apply

## Prompting and Validation

* automatic stop phrases

* syntax improvements
    - multi-line strings

* a stdlib of validation logic
    - e.g. `IS_WORD(<var>)`

* hole variable value transformations:
    - `"The categories are [list(CATEGORIES)]"` or `"The categories are [list(CATEGORIES)]"`
        - result: `CATEGORIES = ["c1", "c2", ...]`
        - also add validation to ensure that the returned CATEGORIES string matches "a, b, and c"
    - `The answer is [strip(ANSWER)]`
        - result: `ANSWER = ANSWER.strip()`
    - semantics:
        - in the following uses, we can replace the variable value by its transformation result
        - in decoding with rewriting support, we can also rewrite the prompt to use the transformed value (e.g. stripped)

* think about non-declarative syntax, e.g. 
    - closer to plain python
    - allows intuitiv use of prompt variables in constraints
    
    - example:
    ```python
    @lmql.beam(num_beams=4, no_repeat_ngram_size=1, do_sample=False, model="EleutherAI/gpt-j-6B")
    def query(OPTIONS):
        "Pick the odd word out: {OPTIONS}.\n"
        "The categories are [CATEGORIES]:\n"
        CATEGORIES = list(CATEGORIES.split(", "))
        
        for o in OPTIONS.split(", "):
            "{o} is a [CATEGORY], "
            assert CATEGORY in CATEGORIES
        
        "\nso the least fitting is [RESULT]"

        return RESULT
    ```
