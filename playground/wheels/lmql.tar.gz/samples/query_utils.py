def scripted_prompt(*args):
    return "And therefore, the books nowadays specify the exact value as"

def parser(s):
    return True