# Datasets 

* HotspotQA
* AlfWorld (worldnavigation)

# Conversational Query

```sql
BEAM
    "Question: Aside from the Apple Remote, what other device can control the program Apple Remote 
    was originally designed to interact with?"
    
    (
        "Thought {i}: [THOUGHT]"
        "Act. {i}: [ACT] [SUBJ]"
        {run_action(ACT, SUBJ)}
    ) for i in range({MAX_ITERATIONS})
WHERE 
    ACT IN SET("Search", "Finish")
```


```python
def run_action(a, subject):
    if a == "Finish":
        raise LMQL.BreakLoopException()
    elif a == "Search":
        # query wikipedia for subject
        return wikipedia(subject)
```


# As Python-based DSL 

```python

def wikipedia(subject): ...
 
def reason_n_act(q):
    BEAM(p=2, n=3)
    MODEL "gpt-3"

    "Question: Aside from the Apple Remote, what other device can control the program Apple Remote was originally designed to interact with?"

    for i in range(max_iterations):
        q"Thought {i}: [THOUGHT]"
        q"Act. {i}: [ACT] [SUBJ]" where ACT in ["Search", "Finish"]
        
        if ACT == "Finish":
            break
        elif ACT == "Search":
            # query wikipedia for subject
            q"Obs. {i}: {wikipedia(subject)}"

    return THOUGHT
```