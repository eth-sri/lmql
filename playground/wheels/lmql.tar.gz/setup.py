from setuptools import setup
import os

setup(
    name='lmql',
    version='0.1.0',    
    description='A query language for language models.',
    url='https://github.com/eth-sri/lmql',
    author='Luca Beurer-Kellner, Marc Fischer, Martin Vechev',
    author_email='luca.beurer-kellner@inf.ethz.ch',
    license='',
    packages=[
        'lmql', 
        *[f"lmql.{p}" for p in os.listdir("lmql") if os.path.isdir(f"lmql/{p}") and p != "tests"],
        'lmql.runtime.postprocessing',

    ],
    install_requires=[
        "astunparse"
    ],

    classifiers=[],
)