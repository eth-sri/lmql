import lmql.runtime.lmql_runtime as lmql

async def query():
   lmql.set_model('mock')
   # where
   intm0 = lmql.EqOp([lmql.SelectOp(lmql.Var('JOKE'), 0), 'Hello'])
   intm1 = lmql.Lt([lmql.LenOp(lmql.Var('JOKE')), 3])
   intm2 = lmql.AndOp([
     intm0,
     intm1
   ])
   lmql.set_where_clause(intm2)
   lmql.set_model('mock')
   # prompt
   (await lmql.query(f'Consider this funny joke: [JOKE]'))
   JOKE = lmql.get_var('JOKE')
   return lmql.get_all_vars()
