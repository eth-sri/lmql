from dataclasses import dataclass

class LMQLRuntime:
    prefers_compact_mask = False