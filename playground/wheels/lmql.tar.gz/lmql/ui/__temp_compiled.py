import lmql.runtime.lmql_runtime as lmql

@lmql.query(None)
async def query(QUESTION=None,OPTIONS_LIST=None,context=None):
   context.set_model('facebook/opt-350m')
   context.set_decoder('argmax', distribution_batch_size=1)
   # where
   intm0 = lmql.AndOp([
     lmql.StopAtOp([lmql.Var('REASONING'), '\n']),
     lmql.StopAtOp([lmql.Var('REASONING'), 'So the answer'])
   ])
   context.set_where_clause(intm0)
   # prompt
   (yield context.query(f'Q:  Today is Christmas Eve of 1937. What is the date 10 days ago in MM/DD/YYYY?\n'))
   (yield context.query(f'Options: 12/14/2026, 12/14/1950, 12/14/2007, 12/14/1937, 07/14/1938, 12/14/1988'))
   (yield context.query(f"A: Let's think step by step.\n If today is Christmas Eve of 1937, then today's date is December 24, 1937. 10 days before today is December 14, 1937, that is 12/14/1937."))
   (yield context.query(f' So the answer is (D).\n\n'))
   (yield context.query(f'Q: Tomorrow is 11/12/2019. What is the date one year ago from today in MM/DD/YYYY?\n'))
   (yield context.query(f'Options: 09/04/2018, 11/11/2018, 08/25/2018, 11/02/2018, 11/04/2018'))
   (yield context.query(f"A: Let's think step by step.\n If tomorrow is 11/12/2019, then today is 11/11/2019. The date one year ago from today is 11/11/2018."))
   (yield context.query(f' So the answer is 11/11/2018.\n\n'))
   (yield context.query(f'Q: {QUESTION}\n'))
   (yield context.query(f'Options: {OPTIONS_LIST}\n'))
   (yield context.query(f"A: Let's think step by step.\n[REASONING] "))
   REASONING = context.get_var('REASONING')
   if REASONING.endswith('So the answer'):
       (yield context.query(f'is '))
   else:
       (yield context.query(f'So the answer is '))
   (yield context.query(f'[distribution:RESULT]'))
   # distribution
   context.set_distribution('RESULT', OPTIONS_LIST.split(', '))
   yield ('result', context.get_return_value())
