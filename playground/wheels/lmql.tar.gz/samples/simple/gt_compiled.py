import lmql.runtime.lmql_runtime as lmql

async def query(FEW_SHOT_EXAMPLES=None):
   lmql.set_model('mock')
   # where
   intm0 = lmql.Gt([lmql.LenOp([lmql.Var('JOKE')]), 4])
   lmql.set_where_clause(intm0)
   lmql.set_model('mock')
   # prompt
   (await lmql.query(f'{FEW_SHOT_EXAMPLES}'))
   (await lmql.query(f'Consider this funny joke: [JOKE]'))
   JOKE = lmql.get_var('JOKE')
   return lmql.get_all_vars()
