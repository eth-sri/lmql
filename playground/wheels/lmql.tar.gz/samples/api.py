import sys
sys.path.append("../")
import lmql
import asyncio

async def main():
    query = """
argmax
 "A list of good dad jokes. A indicates the punchline \\n"
 "Q: How does a penguin build its house? \\n"
 "A: Igloos it together. END \\n"
 "Q: Which knight invented King Arthur's Round Table? \\n"
 "A: Sir Cumference. END \\n"
 "Q:[JOKE] \\n"
 "A:[PUNCHLINE] \\n"
FROM
   'openai/text-davinci-003'
"""
    print(query)
    await lmql.run(query)

asyncio.run(main())