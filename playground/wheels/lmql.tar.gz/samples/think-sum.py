# think-sum: https://arxiv.org/pdf/2210.01293.pdf

import itertools

def q(*args): ...
def lmql(*args): ...

def think(term, definition):
    # return q(f"""
    # BEAM(p=4,k=2) 
    #     "{term}. Examples: \n 1. [list]"
    # FROM 
    #     "gpt-3"
    # """).list.split(",")

    return lmql() \
            .beam(p=4,k=2) \
            .prompt(f"{term}. Examples: [list]") \
            .from_model("gpt-3") \
        .list.str.split(",")

def think_sum():
    # think
    word1_examples = think("binne", "A binne is a furry, four-legged creature.")
    word2_examples = think("bam", "A bam is a simple dwelling.")

    # sum
    result_distr = {}
    for r1,r2 in itertools.product(word1_examples, word2_examples):
        h = q(f"""
        ARGMAX
            "A {r1} {r2} is a place for [RESULT]."
        FROM
            "gpt-3"
        WHERE
            RESULT in SET("animals", "people", "birds", "researchers")
        """).RESULT
        
        result_distr[h.str] += h.prob
    
    return result_distr.argmax()

# group by marginalization
# return distribution via DISTRIBUTION sampling
"""
DISTRIBUTION
    "A {r1} {r2} is a place for [RESULT]."
FROM
    "gpt-3"
WHERE
    RESULT in SET("animals", "people", "birds", "researchers") AND
    r1 in ITEMS(BEAM(p=4,k=2) "{term1_def}. Examples: \n 1. [list]" FROM "gpt-3") AND
    r2 in ITEMS(BEAM(p=4,k=2) "{term2_def}. Examples: \n 1. [list]" FROM "gpt-3")
GROUP BY 
    r1,r2
"""

@lmql.beam(p=4, k=2, model="gpt-3")
def get_examples(definition):
    q"{definition} Examples: \n 1. [list]"
    return list.split("\n")

@lmql.distribution()
def think_sum_pylq(term1_def, term2_def):
    examples1 = get_examples(term1_def)
    examples2 = get_examples(term2_def)
    
    q"A [r1] [r2] is a place for [RESULT]"
    
    assert r1 in examples1
    assert r2 in examples2
    assert RESULT in ["animals", "people", "birds", "researchers"]

    groupby RESULT

    
