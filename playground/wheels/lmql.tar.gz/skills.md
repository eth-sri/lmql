### LMQL Skills: Language Models Calling User-Defined Functions

* define LM-accessible user function as simple python
* LMQL decoder automatically detects calls to skill functions and enforces 
  constraints on parameters to match function signatures and argument types
* `demo` keyword in query inserts skill demonstrations into the prompt

```python
@skill
def search(query: str):
    """
    This skill allows the LM to search the internet using Google.

    Demonstration:
    To search the internet for a search term <TERM> you can use the syntax.
    
    search(<TERM>)
    """
    return bing.search(query)

@skill
def calc(op1: int, op2: int, operator: str):
    """
    This skill allows the LM to perform arbitrary arithmetic calculations.
    
    Demonstration:
    To perform arithmetic computations you can use the following syntax.
    
    calc(<OP1>, <OP2>, <OPERATOR>).

    For example, for addition you can run:

    calc(12, 67, "+") # 73
    """
    return eval(f"{op1} {operator} {op2}")

ARGMAX
    demo search, calc # demonstrate skill using their doc string Demonstration part

    "Question: {QUESTION}:"
    "Reasoning: [REASONING]"
    "Final Answer: [ANSWER]"
WHERE
    enable_skill(REASONING)
```

