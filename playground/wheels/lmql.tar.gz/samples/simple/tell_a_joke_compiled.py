import lmql.runtime.lmql_runtime as lmql

async def query():
   lmql.set_model('gpt2-medium')
   lmql.set_decoder('BEAM', num_beams=4, no_repeat_ngram_size=1, do_sample=False)
   # where
   lmql.set_where_clause(lmql.StopAtOp([lmql.Var('JOKE'), '?']))
   # prompt
   (await lmql.query(f'A list of good dad jokes. A indicates the punchline \n'))
   (await lmql.query(f'Q1: How does a penguin build its house? \n'))
   (await lmql.query(f'A1: Igloos it together. \n'))
   (await lmql.query(f"J2: Which knight invented King Arthur's Round Table? \n"))
   (await lmql.query(f'A2: Sir Cumference. \n'))
   (await lmql.query(f'Q3: [JOKE] \n'))
   JOKE = lmql.get_var('JOKE')
   (await lmql.query(f'A3: [PUNCHLINE]\n'))
   PUNCHLINE = lmql.get_var('PUNCHLINE')
   return lmql.get_default_result()
