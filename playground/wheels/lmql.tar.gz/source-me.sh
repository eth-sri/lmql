LMQL_PATH=$(realpath $(dirname "${BASH_SOURCE[0]}"))
alias lmql="PYTHONPATH=$LMQL_PATH python -m lmql.cli \$*"