import lmql.runtime.lmql_runtime as lmql

async def query():
   lmql.set_model('mock')
   # where
   intm0 = lmql.Lt([lmql.LenOp([lmql.Var('JOKE')]), 10])
   lmql.set_where_clause(intm0)
   lmql.set_model('mock')
   # prompt
   (await lmql.query(f'Q1: How does a penguin build its house? \n'))
   (await lmql.query(f'A1: Igloos it together. \n'))
   (await lmql.query(f"J2: Which knight invented King Arthur's Round Table? \n"))
   (await lmql.query(f'A2: Sir Cumference. \n'))
   (await lmql.query(f'Q3: [JOKE] \n'))
   JOKE = lmql.get_var('JOKE')
   (await lmql.query(f'A3: [PUNCHLINE] \n'))
   PUNCHLINE = lmql.get_var('PUNCHLINE')
   return lmql.get_default_result()
